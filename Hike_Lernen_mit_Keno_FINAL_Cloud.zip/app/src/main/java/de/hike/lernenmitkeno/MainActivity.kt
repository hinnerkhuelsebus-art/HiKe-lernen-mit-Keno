package de.hike.lernenmitkeno

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

data class Vocab(val foreign: String, val native: String)

val Context.hikeDataStore by preferencesDataStore(name = "hike_data")

class MainActivity : ComponentActivity() {
    private val cameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> cameraPermissionGranted = granted }

    private var cameraPermissionGranted by mutableStateOf(false)
    private var imageCapture: ImageCapture? = null
    private var onOcrResult: ((String) -> Unit)? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cameraPermissionGranted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        setContent { HikeApp() }
    }

    fun requestCamera() {
        if (!cameraPermissionGranted) cameraPermission.launch(Manifest.permission.CAMERA)
    }

    fun takePhotoAndRead(onResult: (String) -> Unit) {
        val capture = imageCapture ?: return
        onOcrResult = onResult
        val file = java.io.File.createTempFile("hike_page_", ".jpg", cacheDir)
        val output = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(output, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(result: ImageCapture.OutputFileResults) {
                    try {
                        val image = InputImage.fromFilePath(this@MainActivity, android.net.Uri.fromFile(file))
                        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                            .process(image)
                            .addOnSuccessListener { result -> onOcrResult?.invoke(result.text) }
                            .addOnFailureListener { onOcrResult?.invoke("") }
                    } catch (_: Exception) {
                        onOcrResult?.invoke("")
                    }
                }
                override fun onError(exception: ImageCaptureException) {
                    onOcrResult?.invoke("")
                }
            })
    }

    @Composable
    fun CameraScreen(onText: (String) -> Unit, back: () -> Unit) {
        val context = LocalContext.current
        LaunchedEffect(Unit) {
            requestCamera()
        }
        if (!cameraPermissionGranted) {
            Column(
                Modifier.fillMaxSize().padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("Hike braucht die Kamera, um eine Buchseite zu lesen.")
                Button({ requestCamera() }) { Text("Kamera erlauben") }
                TextButton(back) { Text("Zurück") }
            }
            return
        }

        Box(Modifier.fillMaxSize()) {
            AndroidView(
                factory = { ctx ->
                    val previewView = PreviewView(ctx)
                    val providerFuture = ProcessCameraProvider.getInstance(ctx)
                    providerFuture.addListener({
                        val provider = providerFuture.get()
                        val preview = Preview.Builder().build().also {
                            it.surfaceProvider = previewView.surfaceProvider
                        }
                        imageCapture = ImageCapture.Builder().build()
                        provider.unbindAll()
                        provider.bindToLifecycle(
                            this@MainActivity,
                            CameraSelector.DEFAULT_BACK_CAMERA,
                            preview,
                            imageCapture
                        )
                    }, ContextCompat.getMainExecutor(ctx))
                    previewView
                },
                modifier = Modifier.fillMaxSize()
            )
            Column(
                Modifier.align(Alignment.BottomCenter).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Button(
                    onClick = { takePhotoAndRead(onText) },
                    modifier = Modifier.fillMaxWidth().height(60.dp)
                ) { Text("📸  Seite fotografieren") }
                TextButton(onClick = back) { Text("Abbrechen") }
            }
        }
    }

    @Composable
    fun HikeApp() {
        var screen by remember { mutableStateOf("home") }
        var vocabs by remember { mutableStateOf(emptyList<Vocab>()) }
        var ocrText by remember { mutableStateOf("") }
        var mastery by remember { mutableStateOf(mapOf<String, Int>()) }
        val scope = rememberCoroutineScope()
        val context = LocalContext.current

        LaunchedEffect(Unit) {
            val prefs = context.hikeDataStore.data.first()
            val rawVocabs = prefs[stringPreferencesKey("vocabs")] ?: "[]"
            val rawMastery = prefs[stringPreferencesKey("mastery")] ?: "{}"
            val arr = JSONArray(rawVocabs)
            vocabs = buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(Vocab(o.getString("foreign"), o.getString("native")))
                }
            }
            val obj = JSONObject(rawMastery)
            mastery = buildMap {
                obj.keys().forEach { key -> put(key, obj.getInt(key)) }
            }
        }

        fun persist() {
            scope.launch {
                context.hikeDataStore.edit { prefs ->
                    val arr = JSONArray()
                    vocabs.forEach { v ->
                        arr.put(JSONObject().put("foreign", v.foreign).put("native", v.native))
                    }
                    val obj = JSONObject()
                    mastery.forEach { (k, v) -> obj.put(k, v) }
                    prefs[stringPreferencesKey("vocabs")] = arr.toString()
                    prefs[stringPreferencesKey("mastery")] = obj.toString()
                }
            }
        }

        MaterialTheme {
            Scaffold(topBar = {
                TopAppBar(title = { Text("Hike – Lernen mit Keno") })
            }) { padding ->
                when (screen) {
                    "home" -> Home(padding, vocabs.size,
                        { screen = "learn" }, { screen = "add" },
                        { screen = "list" }, { screen = "camera" })
                    "camera" -> CameraScreen(
                        onText = { ocrText = it; screen = "review" },
                        back = { screen = "home" }
                    )
                    "review" -> Review(padding, ocrText) { selected ->
                        vocabs = (vocabs + selected).distinctBy { it.foreign.lowercase() to it.native.lowercase() }
                        persist()
                        screen = "home"
                    }
                    "learn" -> Learn(padding, vocabs, mastery,
                        onResult = { key, correct ->
                            mastery = mastery.toMutableMap().apply {
                                this[key] = ((this[key] ?: 0) + if (correct) 1 else -1).coerceIn(-3, 5)
                            }
                            persist()
                        }) { screen = "home" }
                    "add" -> Add(padding) { new -> vocabs = (vocabs + new).distinctBy { it.foreign.lowercase() to it.native.lowercase() }; persist(); screen = "home" }
                    else -> VocabList(padding, vocabs) { screen = "home" }
                }
            }
        }
    }

    @Composable
    fun Home(p: PaddingValues, count: Int, learn: () -> Unit, add: () -> Unit,
             list: () -> Unit, camera: () -> Unit) {
        Column(
            Modifier.padding(p).padding(24.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Hallo Keno 👋", style = MaterialTheme.typography.headlineMedium)
            Text("$count Vokabeln gespeichert.")
            Button(learn, Modifier.fillMaxWidth().height(60.dp)) { Text("🧠  Jetzt lernen") }
            Button(camera, Modifier.fillMaxWidth().height(60.dp)) { Text("📸  Buchseite fotografieren") }
            OutlinedButton(add, Modifier.fillMaxWidth().height(60.dp)) { Text("➕  Vokabel hinzufügen") }
            OutlinedButton(list, Modifier.fillMaxWidth().height(60.dp)) { Text("📚  Meine Vokabeln") }
        }
    }

    @Composable
    fun Review(p: PaddingValues, raw: String, save: (List<Vocab>) -> Unit) {
        var rows by remember(raw) {
            mutableStateOf(parsePairs(raw).toMutableStateList())
        }
        Column(Modifier.padding(p).padding(16.dp).fillMaxSize()) {
            Text("Erkannte Vokabeln", style = MaterialTheme.typography.headlineSmall)
            Text("Bitte kurz prüfen. Hike übernimmt nur erkannte Wortpaare.")
            Spacer(Modifier.height(8.dp))
            LazyColumn(Modifier.weight(1f)) {
                items(rows) { v ->
                    ListItem(
                        headlineContent = { Text(v.foreign) },
                        supportingContent = { Text(v.native) }
                    )
                }
            }
            if (rows.isEmpty()) {
                Text("Keine eindeutigen Wortpaare erkannt. Du kannst sie manuell hinzufügen.")
            }
            Button(
                onClick = { save(rows.toList()) },
                enabled = rows.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) { Text("✓  Vokabeln übernehmen") }
        }
    }

    fun parsePairs(text: String): List<Vocab> {
        val result = mutableListOf<Vocab>()
        val lines = text.lines().map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }

        // 1) Explicit separators: "house - Haus", "house: Haus", etc.
        for (line in lines) {
            val parts = line.split(Regex("\\s+(?:–|-|—|:|;|/)\\s+"), limit = 2)
            if (parts.size == 2 && looksLikeWord(parts[0]) && looksLikeWord(parts[1])) {
                result.add(Vocab(parts[0], parts[1]))
            }
        }

        // 2) Two-column OCR often becomes: "house     Haus".
        // Use a large whitespace gap as the column boundary.
        if (result.isEmpty()) {
            text.lines().forEach { raw ->
                val parts = raw.trim().split(Regex("\\s{3,}"), limit = 2)
                if (parts.size == 2 && looksLikeWord(parts[0]) && looksLikeWord(parts[1])) {
                    result.add(Vocab(parts[0].trim(), parts[1].trim()))
                }
            }
        }

        // 3) Common textbook format: "house Haus" (short phrase on each side).
        if (result.isEmpty()) {
            for (line in lines) {
                val parts = line.split(" ", limit = 2)
                if (parts.size == 2 && looksLikeWord(parts[0]) && looksLikeWord(parts[1])) {
                    result.add(Vocab(parts[0], parts[1]))
                }
            }
        }
        return result.distinctBy { it.foreign.lowercase() to it.native.lowercase() }
            .filter { it.foreign.length <= 60 && it.native.length <= 80 }
    }

    fun looksLikeWord(value: String): Boolean {
        val v = value.trim()
        return v.length in 1..80 && v.any { it.isLetter() } &&
            !v.matches(Regex(".*[.!?]$"))
    }

    @Composable
    fun Learn(
        p: PaddingValues,
        vocabs: List<Vocab>,
        mastery: Map<String, Int>,
        onResult: (String, Boolean) -> Unit,
        back: () -> Unit
    ) {
        var index by remember { mutableIntStateOf(0) }
        var answer by remember { mutableStateOf("") }
        var checked by remember { mutableStateOf(false) }
        var lastCorrect by remember { mutableStateOf(false) }
        if (vocabs.isEmpty()) return
        val ordered = remember(vocabs, mastery) {
            vocabs.sortedBy { mastery["${it.foreign}|${it.native}"] ?: 0 }
        }
        val v = ordered[index % ordered.size]
        Column(Modifier.padding(p).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Text("Vokabel ${index + 1} / ${ordered.size}")
            Text(v.foreign, style = MaterialTheme.typography.displaySmall)
            val score = mastery["${v.foreign}|${v.native}"] ?: 0
            Text(if (score <= 0) "Diese Vokabel kommt jetzt öfter." else "Gut gemacht – du hast sie schon öfter richtig.")
            OutlinedTextField(answer, { answer = it }, label = { Text("Deine Übersetzung") })
            if (checked) Text(if (answer.trim().equals(v.native, true)) "✅ Richtig!" else "❌ Richtig wäre: ${v.native}")
            Button({
                if (!checked) {
                    lastCorrect = answer.trim().equals(v.native, true)
                    checked = true
                    onResult("${v.foreign}|${v.native}", lastCorrect)
                } else {
                    index++; answer = ""; checked = false
                }
            }) { Text(if (!checked) "Prüfen" else "Nächste") }
            TextButton(back) { Text("Beenden") }
        }
    }

    @Composable
    fun Add(p: PaddingValues, onAdd: (Vocab) -> Unit) {
        var en by remember { mutableStateOf("") }; var de by remember { mutableStateOf("") }
        Column(Modifier.padding(p).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Vokabel hinzufügen", style = MaterialTheme.typography.headlineSmall)
            OutlinedTextField(en, { en = it }, label = { Text("Englisch") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(de, { de = it }, label = { Text("Deutsch") }, modifier = Modifier.fillMaxWidth())
            Button({ if (en.isNotBlank() && de.isNotBlank()) onAdd(Vocab(en.trim(), de.trim())) },
                Modifier.fillMaxWidth()) { Text("Speichern") }
        }
    }

    @Composable
    fun VocabList(p: PaddingValues, vocabs: List<Vocab>, back: () -> Unit) {
        Column(Modifier.padding(p).padding(16.dp)) {
            Text("Meine Vokabeln", style = MaterialTheme.typography.headlineSmall)
            LazyColumn(Modifier.weight(1f)) {
                items(vocabs) { v ->
                    ListItem(headlineContent = { Text(v.foreign) }, supportingContent = { Text(v.native) })
                }
            }
            TextButton(back) { Text("Zurück") }
        }
    }
}
